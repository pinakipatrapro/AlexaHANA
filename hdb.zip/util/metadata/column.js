this.view = [
    "Id", "productname", "subcategory", "category", "region", "postalcode", "state", "city",
    "country", "segment", "customername", "shipmode", "customerid", "shipdate", "orderdate",
    "orderid", "discount", "profit", "quantity", "costprice", "taxamount", "sales", "ebida"
    ];